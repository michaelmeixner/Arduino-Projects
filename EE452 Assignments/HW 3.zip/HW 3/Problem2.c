// Michael Meixner, HW 3
// Problem 2
#include <stdio.h>
int number;

void setup()
{
    number = 8;
    if((number % 2) != 0)
    {
        printf("Number is odd.");
    } else
    {
        printf("Number is even.");
    }
}

void loop()
{
    
}

void main() {}